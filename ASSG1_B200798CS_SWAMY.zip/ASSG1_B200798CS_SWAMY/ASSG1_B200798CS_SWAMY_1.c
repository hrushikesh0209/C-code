#include<stdio.h>
#include<math.h>

int main()
{
    int n,remainder,decimalno=0,i=0,j;
    scanf("%d",&n);
    int temp=n;
    while(temp>0)
    {
        remainder=temp%10;
        decimalno+=remainder*pow(8,i);
        temp=temp/10;
        i++;

    }
   
    printf("%d",decimalno);

}