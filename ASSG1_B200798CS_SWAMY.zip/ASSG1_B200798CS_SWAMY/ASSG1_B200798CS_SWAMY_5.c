#include<stdio.h>
#include<string.h>
#include<stdlib.h>

int main()
{
    int m,n,k=0;
    scanf("%d %d",&m,&n);
    int a[m],b[n],merge[m+n],temp[m+n];
    
    for(int i=0;i<m;i++)
        scanf("%d",&a[i]);
    
    for(int j=0;j<n;j++)
        scanf("%d",&b[j]);
    
    for(int k=0;k<m;k++)
        merge[k]=a[k];

    for(int k=m;k<m+n;k++)
        merge[k]=b[k-m];

    for(int i=0;i<m+n;i++)
    {
        int flag=1,count=0;
        for(int j=i;j>0;j--)
        {
            if(merge[i]==merge[j-1])
            {
                flag=0;
                break;
            }
        }
        if(flag==0)
        continue;
        for(int j=i;j<m+n;j++)
        {
            if(merge[i]==merge[j])
            count++;
        }
        if(count>1)
        {
            for(int j=0;j<count;j++)
            printf("%d ",merge[i]);
        }
        else
        {
            temp[k]=merge[i];
            k++;
        }
    }
    for(int i=0;i<k;i++)
    printf("%d ",temp[i]);

    return 0;   
}