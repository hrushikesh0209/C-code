#include<stdio.h>
#include<stdlib.h>
#include<math.h>

int main()
{
  int n,sum=0;
   scanf("%d",&n);
  int inputarr[n],pos[n];
  for(int i=0;i<n;i++)
   scanf("%d",&inputarr[i]);
  
  for(int i=0;i<n;i++)
  {
      int flag=1;
      int count=0,k=0;
      for(int j=i;j>0;j--)
      {
          if(inputarr[i]==inputarr[j-1])
          {
          flag=0;
          break;
          }
      }
      if(flag==0)
      continue;

      for(int j=i;j<n;j++)
      {
          if(inputarr[i]==inputarr[j])
          {
              count++;
              pos[k]=j;
              k++;
          }
      }
      
      
      if(count>1)
      {
          printf("%d ",inputarr[i]);
          for(int z=0;z<count;z++)
          printf("%d ",pos[z]);
          printf("%d\n",count);
          sum++;
      }
      
  }
  if(sum==0)
  printf("-1");
  return 0;
}