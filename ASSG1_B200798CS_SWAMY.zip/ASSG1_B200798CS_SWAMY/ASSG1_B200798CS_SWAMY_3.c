#include<stdio.h>
#include<string.h>
#include<stdlib.h>

int main()
{
    char input[10000],i=0;
    scanf("%[^\n]s",input);
    while(input[i]!=0)
    {
        if(input[i]==32)
        printf(" ");
        else if(input[i]<97)
        printf("%c",input[i]+32);
        else 
        printf("%c",input[i]-32);
        
        i++;
    }
    return 0;
}