#include<stdio.h>
#include<stdlib.h>
#include<math.h>

int gcd(int a,int b)
{
    if(a%b==0)
    return b;
    if(a>b)
    gcd(a,a%b);
    else 
    gcd(b,b%a);
}
int main()
{
    int m,n,a,b;
    scanf("%d %d",&m,&n);
    a=abs(m);
    b=abs(n);
    printf("%d",gcd(a,b));
    return 0;
}