#include<stdio.h>
#include<string.h>
#include<stdlib.h>

int CONVERT(int n)
{
    int temp=n,a[16],i=0;
    for(int i=0;i<16;i++)
     a[i]=0;
    
    for (int i=0;i<16;i++)
    {
     a[15-i]=temp%2;
     temp=temp/2;
    }
    for(int j=0;j<16;j++)
     printf("%d",a[j]);

    printf("\n");
    return 0;
}
int main()
{
    int n,k,p,q;
    scanf("%d %d",&n,&k);
    p=n>>k|n<<(16-k);
    q=n<<k|n>>(16-k);
    CONVERT(n);
    CONVERT(q);
    CONVERT(p);
   
}